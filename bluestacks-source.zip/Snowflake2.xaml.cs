﻿using System.Windows.Controls;

namespace WpfSnowfall.Snowflakes;

/// <summary>
/// Logica di interazione per Snowflake2.xaml
/// </summary>
public partial class Snowflake2 : UserControl
{
    public Snowflake2()
    {
        InitializeComponent();
    }
}
