# Simple GitHub Packaging Script for BlueStacks Project

Write-Host "Packaging BlueStacks project for GitHub..." -ForegroundColor Green
Write-Host ""

# Check if Git is available
$gitAvailable = Get-Command git -ErrorAction SilentlyContinue

if ($gitAvailable) {
    Write-Host "Git is available. Setting up repository..." -ForegroundColor Green
    
    # Initialize repository if needed
    if (-not (Test-Path ".git")) {
        git init
        Write-Host "Initialized Git repository" -ForegroundColor Yellow
    }
    
    # Add all files
    git add .
    Write-Host "Added files to Git staging" -ForegroundColor Yellow
    
    # Create commit if there are changes
    $hasChanges = git diff --cached --quiet; $LASTEXITCODE -ne 0
    if ($hasChanges) {
        git commit -m "Initial commit: BlueStacks WPF application with network interception and gaming features"
        Write-Host "Created initial commit" -ForegroundColor Yellow
    }
    
    Write-Host ""
    Write-Host "SUCCESS: Repository is ready!" -ForegroundColor Green
    Write-Host "Next steps:" -ForegroundColor Cyan
    Write-Host "1. Go to https://github.com/new" -ForegroundColor White
    Write-Host "2. Create a new repository" -ForegroundColor White
    Write-Host "3. Copy the repository URL" -ForegroundColor White
    Write-Host "4. Run: git remote add origin [URL]" -ForegroundColor White
    Write-Host "5. Run: git push -u origin main" -ForegroundColor White
} else {
    Write-Host "Git is not installed. Creating ZIP file..." -ForegroundColor Yellow
    
    # Create output directory
    $outputDir = Split-Path (Get-Location) -Parent
    $zipPath = Join-Path $outputDir "bluestacks-source.zip"
    
    # Remove old zip if exists
    if (Test-Path $zipPath) {
        Remove-Item $zipPath
    }
    
    # Compress files excluding build artifacts
    $exclude = @("bin", "obj", ".vs")
    Get-ChildItem -Recurse | Where-Object {
        $include = $true
        foreach ($ex in $exclude) {
            if ($_.FullName -match "\\$ex\\") {
                $include = $false
                break
            }
        }
        $include -and !$_.PSIsContainer
    } | Compress-Archive -DestinationPath $zipPath
    
    Write-Host ""
    Write-Host "SUCCESS: ZIP file created at $zipPath" -ForegroundColor Green
    Write-Host "Upload options:" -ForegroundColor Cyan
    Write-Host "1. Go to https://github.com/new" -ForegroundColor White
    Write-Host "2. Create repository and upload ZIP contents" -ForegroundColor White
    Write-Host "3. Or install Git from: https://git-scm.com/download/windows" -ForegroundColor White
}