# BlueStacks GitHub Setup Script
# This script helps you prepare your project for GitHub

Write-Host "BlueStacks GitHub Setup Script" -ForegroundColor Green
Write-Host "==============================" -ForegroundColor Green
Write-Host ""

# Check if Git is installed
$gitInstalled = $false
$gitCheck = Get-Command git -ErrorAction SilentlyContinue
if ($gitCheck) {
    $gitVersion = & git --version
    Write-Host "✓ Git is installed: $gitVersion" -ForegroundColor Green
    $gitInstalled = $true
} else {
    Write-Host "✗ Git is not installed or not in PATH" -ForegroundColor Red
}

if (-not $gitInstalled) {
    Write-Host ""
    Write-Host "To install Git:" -ForegroundColor Yellow
    Write-Host "1. Download from: https://git-scm.com/download/windows" -ForegroundColor Yellow
    Write-Host "2. Run the installer with default settings" -ForegroundColor Yellow
    Write-Host "3. Restart PowerShell after installation" -ForegroundColor Yellow
    Write-Host "4. Run this script again" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Alternatively, you can:" -ForegroundColor Cyan
    Write-Host "- Use GitHub Desktop (https://desktop.github.com/)" -ForegroundColor Cyan
    Write-Host "- Upload files directly via GitHub web interface" -ForegroundColor Cyan
    Write-Host ""
    
    # Create a zip file for manual upload
    Write-Host "Creating a ZIP file for manual upload..." -ForegroundColor Yellow
    
    $sourceDir = Get-Location
    $zipPath = Join-Path (Split-Path $sourceDir -Parent) "bluestacks-source.zip"
    
    # Get all files except those that should be ignored
    $filesToZip = Get-ChildItem -Recurse | Where-Object {
        $_.FullName -notmatch '\\bin\\' -and
        $_.FullName -notmatch '\\obj\\' -and
        $_.FullName -notmatch '\\.vs\\' -and
        -not $_.PSIsContainer
    }
    
    # Create zip file
    try {
        Add-Type -AssemblyName System.IO.Compression.FileSystem
        if (Test-Path $zipPath) { Remove-Item $zipPath }
        
        $zip = [System.IO.Compression.ZipFile]::Open($zipPath, 'Create')
        
        foreach ($file in $filesToZip) {
            $relativePath = $file.FullName.Substring($sourceDir.Path.Length + 1)
            $entry = $zip.CreateEntry($relativePath)
            $entryStream = $entry.Open()
            $fileStream = [System.IO.File]::OpenRead($file.FullName)
            $fileStream.CopyTo($entryStream)
            $fileStream.Close()
            $entryStream.Close()
        }
        
        $zip.Dispose()
        Write-Host "✓ Created ZIP file: $zipPath" -ForegroundColor Green
        Write-Host "You can upload this ZIP file to GitHub manually." -ForegroundColor Green
    }
    catch {
        Write-Host "Failed to create ZIP file: $($_.Exception.Message)" -ForegroundColor Red
    }
    
    exit 1
}

# If Git is installed, proceed with setup
Write-Host "Setting up Git repository..." -ForegroundColor Yellow

# Initialize git repository if not already done
if (-not (Test-Path ".git")) {
    git init
    Write-Host "✓ Initialized Git repository" -ForegroundColor Green
} else {
    Write-Host "✓ Git repository already exists" -ForegroundColor Green
}

# Add all files
Write-Host "Adding files to Git..." -ForegroundColor Yellow
git add .

# Check if there are any changes to commit
$status = git status --porcelain
if ($status) {
    # Create initial commit
    Write-Host "Creating initial commit..." -ForegroundColor Yellow
    git commit -m "Initial commit - BlueStacks WPF application

Features:
- WPF application with custom controls
- Entity Framework Core with SQLite
- Network interception capabilities
- Bungie API integration
- Data visualization with OxyPlot
- System tray functionality"
    
    Write-Host "✓ Created initial commit" -ForegroundColor Green
} else {
    Write-Host "✓ No changes to commit" -ForegroundColor Green
}

Write-Host ""
Write-Host "Next steps to upload to GitHub:" -ForegroundColor Cyan
Write-Host "1. Create a new repository on GitHub:" -ForegroundColor White
Write-Host "   https://github.com/new" -ForegroundColor Gray
Write-Host "2. Copy the repository URL (HTTPS or SSH)" -ForegroundColor White
Write-Host "3. Run these commands:" -ForegroundColor White
Write-Host "   git remote add origin [YOUR_REPO_URL]" -ForegroundColor Gray
Write-Host "   git branch -M main" -ForegroundColor Gray
Write-Host "   git push -u origin main" -ForegroundColor Gray
Write-Host ""
Write-Host "Repository is ready for GitHub!" -ForegroundColor Green